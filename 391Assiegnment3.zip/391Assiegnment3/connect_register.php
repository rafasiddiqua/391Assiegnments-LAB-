<?php
$username = filter_input(INPUT_POST, 'username');
$email= filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
$confirmpassword= filter_input(INPUT_POST, 'confirmpassword');
$usertype = filter_input(INPUT_POST, 'usertype');
if (!empty($username)){
if (!empty($email)){
if (!empty($password)){
if (!empty($confirmpassword)){
if (!empty($usertype)){	
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, );


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO account (username, email, password, confirmpassword, usertype)
values ('$username','$email', 'password', 'confirmpassword', 'usertype')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Password should not be empty";
die();
}
}
else{
echo "Username should not be empty";
die();
}
?>

