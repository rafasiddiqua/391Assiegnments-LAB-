var  quotes = [
    ["You only live once, but if you do it right, once is enough.","Mae West"],
    ["I am so clever that sometimes I don't understand a single word of what I am saying.","Oscar Wilde"],
    ["Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.","Albert Einstein"],
	["The most beautiful experience we can have is the mysterious. It is the fundamental emotion that stands at the cradle of true art and true science.","Albert Einstein"]
	["It is our choices, Harry, that show what we truly are, far more than our abilities.","J.K. Rowling, Harry Potter and the Chamber of Secrets"],
	["All men who have turned out worth anything have had the chief hand in their own education.","Walter Scott"],
	["Trust yourself. You know more than you think you do.","Benjamin Spock"],
	["No one can make you feel inferior without your consent.","Eleanor Roosevelt, This is My Story"],
	["To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.","Ralph Waldo Emerson"],
	["Twenty years from now you will be more disappointed by the things that you didn't do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover.","H. Jackson Brown Jr., P.S. I Love You"]
	]
function newQuote(){
var randomNumber = Math.floor(Math.random() * (quotes.length));
document.getElementById('quoteDisplay').innerHTML = quotes[randomNumber];
}
newQuote();

function weightConverter(valNum) {
  document.getElementById("outputGrams").innerHTML = valNum / 0.0022046;
}
function calculate() {
  var values = document.getElementById('box1').value.split(/,/g);
  var sum = values.reduce(function(a, b) { return parseInt(a) + parseInt(b); });
  document.querySelector('#max').innerHTML = values.max();
  document.querySelector('#min').innerHTML = values.min();
  document.querySelector('#sum').innerHTML = sum;
  document.querySelector('#avg').innerHTML = sum / values.length;
  document.querySelector('#reverse').innerHTML = values.reverse().join(',');
}

Array.prototype.max = function() {
  return Math.max.apply(null, this);
};

Array.prototype.min = function() {
  return Math.min.apply(null, this);
};

var magic = document.getElementsByTagName('textarea')[0]
document.getElementById('clear').onclick = function () {
magic.value = ''
}
var capitalize = true;
document.getElementById('capitalize').onclick = function () {
if (capitalize) magic.value = input.value.toUpperCase()
else magic.value = magic.value.toLowerCase()
capitalize = !capitalize;
}
document.getElementById('strip').onclick = function () {
var lines = magic.value.split('\n')
for (var i = 0; i < lines.length; i++)
lines[i] = lines[i].trim();
lines = lines.join('\n')
magic.value = lines
}
document.getElementById('sort').onclick = function () {
var lines = magic.value.split('\n')
magic.value = lines.sort().join('\n')
}
document.getElementById('reverse').onclick = function () {
var lines = magic.value.split('\n')
for (var i = 0; i < lines.length; i++) {
var prev = lines[i];
lines[i] = '';
for (var j = 0; j < prev.length; j++)
lines[i] = prev[j] + lines[i];
}
lines = lines.join('\n')
magic.value = lines
}
document.getElementById('addnumber').onclick = function () {
var lines = magic.value.split('\n')
for (var i = 0; i < lines.length; i++)
lines[i] = i + 1 + '. ' + lines[i];
lines = lines.join('\n')
magic.value = lines
}