<?php
   $email = $_POST['email'];
   $phone = $_POST['phone'];
   $password = $_POST['password'];

  
   
   $conn = new mysqli('localhost', 'root', '','assignment');
   if($conn->connect_error){
        die('connection failed : '.$conn->connect_error);
    }else{
    	$stmt = $conn->prepare("insert into login(phone, password, email) values(?, ?, ?)");
    	$stmt->bind_param("is", $phone, $password, $email);
    	$stmt->execute();
      echo "Login successfull";
      echo "<script> location.href='admin.html'; </script>";
     
     $stmt->close();
     $conn->close();
   }
 ?>